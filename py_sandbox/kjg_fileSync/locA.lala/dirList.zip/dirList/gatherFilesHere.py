'''
steps: 
1. load locations of all files
2. copy files to local area
3. done
'''
import os
cmd=os.system
f=file('delme.txt','r')
files=[]
def enclose(a,character):
	return character+a+character
#enclose('test','"') >> '"test"'
j=0
def newname(n):
	return str(j)+'.txt'
#newname(1) >> '1.txt'
for i in f: 
	files.append(i.strip())
	cmd('copy '+enclose(i.strip(),'"')+' '+newname(j))
	j+=1
cmd('dir /b *.txt')